# Homeopathie: Klassieke Basis & Remedies

## Inleiding
Klassieke homeopathie is gebaseerd op het principe "gelijken genezen gelijken" (Similia similibus curentur). Dit document behandelt de basis-principes en praktische toepassing.

## Homeopathische Principes

### Similia Similibus Curentur (Gelijken Genezen Gelijken)
- **Principe:** Een stof die symptomen veroorzaakt kan die symptomen genezen
- **Voorbeeld:** Ui veroorzaakt tranen → Allium cepa genezen tranen
- **Basis:** Lichaam's natuurlijke genezings-mechanisme

### Potentiation (Verdunning & Schudding)
- **Proces:** Stof wordt verdund en geschud
- **Effect:** Hoe meer verdund, hoe sterker
- **Paradox:** Minder moleculen = Meer effect
- **Theorie:** Energetische overdracht

### Individualisering
- **Niet Diagnose-Gericht:** Niet "genees ziekte"
- **Symptoom-Gericht:** Genees persoon met symptomen
- **Totaal Beeld:** Fysiek, mentaal, emotioneel
- **Uniek:** Elke persoon krijgt ander remedy

### Materia Medica (Remedie-Kennis)
- **Basis:** Symptoom-patroon van remedy
- **Onderzoek:** Hoe remedy op gezonde persoon werkt
- **Toepassing:** Match remedy aan symptoom-patroon
- **Diepgang:** Veel informatie per remedy

---

## Homeopathische Potentie-Niveaus

### Laag Potent (6X, 12X, 6C)
- **Verdunning:** Minder verdund
- **Moleculen:** Meer moleculen aanwezig
- **Effect:** Meer fysiek
- **Gebruik:** Acute problemen, frequenter

### Middel Potent (30C)
- **Verdunning:** Gemiddeld verdund
- **Moleculen:** Minder moleculen
- **Effect:** Balans fysiek-mentaal
- **Gebruik:** Algemeen gebruik

### Hoog Potent (200C, 1M)
- **Verdunning:** Zeer verdund
- **Moleculen:** Zeer weinig moleculen
- **Effect:** Meer energetisch-mentaal
- **Gebruik:** Chronische problemen, voorzichtig

### Zeer Hoog Potent (10M+)
- **Verdunning:** Extreem verdund
- **Moleculen:** Bijna geen moleculen
- **Effect:** Zeer energetisch
- **Gebruik:** Professioneel, voorzichtig

---

## Veel Gebruikte Homeopathische Remedies

### ARNICA MONTANA (Bergwondkruid)

**Symptoom-Patroon:**
- Trauma (fysiek of emotioneel)
- Blauwe plekken
- Spierpijn
- Schok
- Angst na trauma

**Dosering:**
- **Acute:** 30C, elke 1-2 uur
- **Chronisch:** 30C, 1-2x dagelijks
- **Duur:** 7-14 dagen

**Timing:**
- Zo snel mogelijk na trauma
- Kan langdurig gebruikt worden

### IGNATIA AMARA (Sint Ignatius Boon)

**Symptoom-Patroon:**
- Emotioneel trauma
- Verdriet
- Teleurstelling
- Snikken, huilen
- Stemmingswisselingen

**Dosering:**
- **Acute:** 30C, elke 1-2 uur
- **Chronisch:** 30C, 1-2x dagelijks
- **Duur:** 2-4 weken

**Timing:**
- Direct na emotioneel trauma
- Voor rouwperiodes

### PULSATILLA (Pasque Bloem)

**Symptoom-Patroon:**
- Gevoeligheid
- Behoefte aan troost
- Wisselende symptomen
- Milde temperament
- Emotionele gevoeligheid

**Dosering:**
- **Acute:** 30C, 2-3x dagelijks
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 2-4 weken

**Timing:**
- Voor gevoelige personen
- Voor wisselende symptomen

### SULPHUR (Zwavel)

**Symptoom-Patroon:**
- Huid-problemen
- Hitte-sensaties
- Itching
- Lichaamsgeur
- Chronische problemen

**Dosering:**
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 4-8 weken
- **Voorzichtigheid:** Kan "homeopathische crisis" veroorzaken

**Timing:**
- Voor chronische huid-problemen
- Voor diepe detoxificatie

### LYCOPODIUM (Wolfsklauwtje)

**Symptoom-Patroon:**
- Zelfvertrouwen-problemen
- Spijsverteringsproblemen
- Rechter-zijde symptomen
- Angst voor falen
- Vermoeidheid

**Dosering:**
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 4-8 weken

**Timing:**
- Voor zelfvertrouwen-problemen
- Voor spijsverteringsproblemen

### CALCAREA CARBONICA (Kalkschelppoeder)

**Symptoom-Patroon:**
- Zwakte
- Vermoeidheid
- Angst
- Zweten
- Langzame genezing

**Dosering:**
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 4-8 weken

**Timing:**
- Voor chronische zwakte
- Voor langzame genezing

### NUXVOMICA (Nootmuskaat)

**Symptoom-Patroon:**
- Spijsverteringsproblemen
- Constipatie
- Irritabiliteit
- Overwerk
- Stress-gerelateerde problemen

**Dosering:**
- **Acute:** 30C, 2-3x dagelijks
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 2-4 weken

**Timing:**
- Voor stress-gerelateerde problemen
- Voor spijsverteringsproblemen

### SEPIA (Inktvis-Inkt)

**Symptoom-Patroon:**
- Vermoeidheid
- Emotionele afstandelijkheid
- Vrouwelijke hormonale problemen
- Gevoeligheid
- Behoefte aan rust

**Dosering:**
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 4-8 weken

**Timing:**
- Voor hormonale problemen
- Voor emotionele vermoeidheid

### PHOSPHORUS (Fosfor)

**Symptoom-Patroon:**
- Angst
- Gevoeligheid
- Energie-problemen
- Hartklachten
- Bloedingen

**Dosering:**
- **Acute:** 30C, 1-2x dagelijks
- **Chronisch:** 30C, 1x dagelijks
- **Duur:** 2-4 weken

**Timing:**
- Voor angst
- Voor energie-problemen

---

## Homeopathische Toepassing per Aandoening

### Voor Slaapproblemen
- **Remedy:** Ignatia (emotioneel), Coffea (overmatige gedachten)
- **Dosering:** 30C, 1x voor bed
- **Duur:** 2-4 weken

### Voor Stress & Angst
- **Remedy:** Aconite (acute angst), Phosphorus (chronische angst)
- **Dosering:** 30C, 1-2x dagelijks
- **Duur:** 2-4 weken

### Voor Spijsverteringsproblemen
- **Remedy:** Nux Vomica, Lycopodium
- **Dosering:** 30C, 2-3x dagelijks
- **Duur:** 2-4 weken

### Voor Huid-Problemen
- **Remedy:** Sulphur, Graphites
- **Dosering:** 30C, 1x dagelijks
- **Duur:** 4-8 weken

### Voor Energie & Vermoeidheid
- **Remedy:** Calcarea Carbonica, Sepia
- **Dosering:** 30C, 1x dagelijks
- **Duur:** 4-8 weken

### Voor Emotionele Problemen
- **Remedy:** Ignatia (verdriet), Pulsatilla (gevoeligheid)
- **Dosering:** 30C, 1-2x dagelijks
- **Duur:** 2-4 weken

---

## Homeopathische Voorzorgsmaatregelen

### Wat Te Vermijden
- **Sterke Geuren:** Kan remedy verstoren (munt, eucalyptus)
- **Elektrische Apparaten:** Kan remedy verstoren
- **Extreme Temperaturen:** Bewaar op kamertemperatuur
- **Licht:** Bewaar in donker

### Hoe Te Nemen
- **Timing:** 30 minuten voor/na eten
- **Methode:** Laat korrels onder tong smelten
- **Dosis:** 3-5 korrels per keer
- **Frequentie:** Afhankelijk van remedy

### Wanneer Voorzichtig Zijn
- Zwangerschap (consult homeopaat)
- Ernstige ziekten (consult arts)
- Met medicijnen (kan interactie hebben)
- Zeer gevoelige personen

### Homeopathische Reacties
- **Erstvergergering:** Symptomen worden eerst erger
- **Duur:** Meestal 1-3 dagen
- **Voordeel:** Teken dat remedy werkt
- **Actie:** Wacht, symptomen verbeteren

---

## Klassieke Homeopathische Benadering

### Anamnese
- **Diepgang:** Zeer gedetailleerde vragenlijst
- **Totaal Beeld:** Fysiek, mentaal, emotioneel
- **Uniek:** Elke persoon ander remedy
- **Tijd:** Kan 1-2 uur duren

### Remedy-Selectie
- **Matching:** Match symptoom-patroon aan remedy
- **Materia Medica:** Raadpleeg remedy-kennis
- **Ervaring:** Klassieke homeopaten hebben veel ervaring
- **Voorzichtig:** Juiste remedy is cruciaal

### Monitoring
- **Follow-up:** Regelmatige check-ins
- **Aanpassingen:** Remedy kan aangepast worden
- **Duur:** Chronische problemen nemen maanden
- **Geduld:** Klassieke homeopathie is langzaam

---

## Voordelen van Klassieke Homeopathie

### Veiligheid
- Geen bijwerkingen
- Geen toxiciteit
- Geen afhankelijkheid
- Zeer veilig

### Effectiviteit
- Kan zeer effectief zijn
- Ondersteunt lichaam's eigen genezing
- Lange-termijn resultaten
- Preventie mogelijk

### Holistische Benadering
- Behandelt hele persoon
- Niet alleen symptomen
- Ondersteunt gezondheid
- Preventie-gericht

---

## Voorzorgsmaatregelen & Beperkingen

### Wanneer Niet Te Gebruiken
- Acuut medisch noodgeval (ga naar ziekenhuis)
- Ernstige infecties (kan antibiotica nodig hebben)
- Chirurgische problemen
- Ernstige mentale gezondheid-problemen

### Combinatie Met Andere Behandelingen
- Kan gecombineerd worden met voeding
- Kan gecombineerd worden met leefstijl
- Voorzichtig met medicijnen
- Consult arts/homeopaat

### Professionele Hulp
- Klassieke homeopathie is complex
- Professionele homeopaat aanbevolen
- Zelfmedicatie kan werken, maar minder effectief
- Consult professioneel voor chronische problemen

---

## Referenties & Onderzoeksbronnen
- Klassieke Homeopathie Boeken (Hahnemann, Kent)
- Materia Medica Referenties
- Homeopathie Onderzoeken
- Klassieke Homeopaten Ervaringen
