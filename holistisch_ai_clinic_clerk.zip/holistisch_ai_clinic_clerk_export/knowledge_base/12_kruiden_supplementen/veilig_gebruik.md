# Kruiden & Supplementen: Veilig Gebruik & Interacties

## Inleiding
Kruiden en supplementen kunnen krachtige gezondheids-instrumenten zijn, maar moeten voorzichtig gebruikt worden. Verkeerde timing, dosering of combinaties kunnen schadelijk zijn. Dit document behandelt veilig gebruik.

## Fundamentele Principes

### Voorzichtigheid Eerst
- **Niet Alles Tegelijk:** Start met één supplement
- **Lage Dosering:** Begin laag, verhoog geleidelijk
- **Monitoring:** Let op reacties
- **Timing:** Timing is cruciaal
- **Combinaties:** Sommige combinaties zijn gevaarlijk

### Bloedwaardes Checken
- **Essentieel:** Check bloedwaardes VOOR supplementen
- **Baseline:** Weet je huidige niveaus
- **Monitoring:** Check regelmatig
- **Aanpassingen:** Pas aan op basis van resultaten

### Fase-Afhankelijke Toepassing
- **Acute Fase:** Andere supplementen dan chronische fase
- **Herstel-Fase:** Andere dan onderhoud
- **Individueel:** Hangt af van persoon en toestand

---

## Veel Gebruikte Supplementen: Veilig Gebruik

### MAGNESIUM

**Voordelen:**
- Ondersteunt slaap
- Vermindert spierverkramping
- Ondersteunt hartfunctie
- Kalmerend effect

**Dosering:**
- **Beginner:** 200-300mg dagelijks
- **Therapeutisch:** 400-500mg dagelijks
- **Maximum:** 1000mg dagelijks (consult arts)

**Timing:**
- **Beste:** Avond (1-2 uur voor bed)
- **Met Voeding:** Kan met voeding
- **Niet Met:** Calcium (interactie)

**Voorzichtigheid:**
- Kan laxatief effect hebben (start laag)
- Niet met bepaalde medicijnen
- Consult arts bij nierproblemen

**Vormen:**
- **Magnesium Glycinate:** Beste (goed opneembaar, geen laxatief effect)
- **Magnesium Threonate:** Voor hersenen
- **Magnesium Citrate:** Laxatief effect
- **Magnesium Oxide:** Slecht opneembaar

### ZINK

**Voordelen:**
- Ondersteunt immuunsysteem
- Ondersteunt darmwand (met L-carnosine)
- Ondersteunt reproductieve gezondheid
- Ondersteunt oog-gezondheid

**Dosering:**
- **Beginner:** 10-15mg dagelijks
- **Therapeutisch:** 20-30mg dagelijks
- **Maximum:** 40mg dagelijks

**Timing:**
- **Beste:** Ochtend (met voeding)
- **Niet Met:** Calcium, ijzer (interactie)
- **Afstand:** 2 uur van andere supplementen

**Voorzichtigheid:**
- Teveel zink kan kopergetal verlagen
- Check koperniveaus
- Kan misselijkheid veroorzaken (met voeding nemen)
- Niet langdurig hoge dosering

**Vormen:**
- **Zink Picolinate:** Goed opneembaar
- **Zink Citrate:** Goed opneembaar
- **Zink Oxide:** Slecht opneembaar

### IJZER

**Voordelen:**
- Ondersteunt energieniveaus
- Ondersteunt zuurstof-transport
- Ondersteunt immuunsysteem

**Dosering:**
- **Beginner:** 10-15mg dagelijks
- **Therapeutisch:** 20-30mg dagelijks
- **Maximum:** 40mg dagelijks

**Timing:**
- **Beste:** Ochtend (op lege maag of met vitamine C)
- **Niet Met:** Calcium, magnesium, zink (interactie)
- **Afstand:** 2-3 uur van andere supplementen

**Voorzichtigheid:**
- Teveel ijzer kan schadelijk zijn
- Check ijzerniveaus EERST
- Kan maagpijn veroorzaken
- Kan verstopte stoelgang veroorzaken

**Vormen:**
- **Ijzer Bisglycinate:** Goed opneembaar, minder bijwerkingen
- **Ijzer Citrate:** Goed opneembaar
- **Ijzer Sulfaat:** Goedkoop, meer bijwerkingen

### VITAMINE D

**Voordelen:**
- Ondersteunt immuunsysteem
- Ondersteunt botgezondheid
- Ondersteunt stemming
- Ondersteunt slaap-waak-cyclus

**Dosering:**
- **Beginner:** 1000-2000 IU dagelijks
- **Therapeutisch:** 2000-4000 IU dagelijks
- **Maximum:** 4000 IU dagelijks (consult arts)

**Timing:**
- **Beste:** Ochtend (met voeding)
- **Met Vet:** Beter opneembaar (neem met olie)
- **Niet Met:** Calcium (interactie)

**Voorzichtigheid:**
- Check vitamine D-niveaus EERST
- Teveel kan toxisch zijn
- Langdurig hoge dosering kan problematisch zijn
- Consult arts bij nierproblemen

**Vormen:**
- **Vitamine D3:** Beter dan D2
- **Vitamine D2:** Minder effectief

### OMEGA-3 (VETZUREN)

**Voordelen:**
- Ondersteunt hartgezondheid
- Ondersteunt hersenfunction
- Vermindert inflammatie
- Ondersteunt slaap

**Dosering:**
- **Beginner:** 500-1000mg EPA+DHA dagelijks
- **Therapeutisch:** 1000-2000mg EPA+DHA dagelijks
- **Maximum:** 3000mg EPA+DHA dagelijks

**Timing:**
- **Beste:** Met voeding (betere opname)
- **Verdeling:** Kan in twee doses
- **Niet Met:** Bloedverdunners (consult arts)

**Voorzichtigheid:**
- Kan bloedverdunning veroorzaken
- Niet met bepaalde medicijnen
- Controleer kwaliteit (oxidatie)
- Consult arts bij bloedstollingsproblemen

**Vormen:**
- **Vis-Olie:** Goed, maar milieu-impact
- **Algen-Olie:** Plantaardig alternatief
- **Krill-Olie:** Goed opneembaar

### PROBIOTICA

**Voordelen:**
- Ondersteunt darmflora
- Ondersteunt immuunsysteem
- Ondersteunt spijsvertering
- Ondersteunt mentale gezondheid

**Dosering:**
- **Beginner:** 5-10 miljard CFU dagelijks
- **Therapeutisch:** 10-50 miljard CFU dagelijks
- **Maximum:** 100+ miljard CFU (afhankelijk van product)

**Timing:**
- **Beste:** Ochtend (op lege maag of met voeding)
- **Afstand:** 2 uur van antibiotica
- **Consistentie:** Dagelijks voor effect

**Voorzichtigheid:**
- Kan detox-reactie veroorzaken (start laag)
- Niet met bepaalde medicijnen
- Kwaliteit varieert (controleer merk)
- Consult arts bij immuun-problemen

**Vormen:**
- **L. Reuteri:** Zeer voordelig
- **Bifidobacterium:** Goed voor darm
- **Lactobacillus:** Goed voor darm
- **Multi-Strain:** Diversiteit beter

### CURCUMINE (KURKUMA)

**Voordelen:**
- Vermindert inflammatie
- Ondersteunt hersenfunction
- Ondersteunt leverfunction
- Antioxidant

**Dosering:**
- **Beginner:** 500-1000mg dagelijks
- **Therapeutisch:** 1000-2000mg dagelijks
- **Maximum:** 3000mg dagelijks

**Timing:**
- **Beste:** Met voeding (betere opname)
- **Met Peper:** Voeg peper toe (verhoogt opname 2000x)
- **Met Vet:** Beter opneembaar

**Voorzichtigheid:**
- Kan bloedverdunning veroorzaken
- Niet met bepaalde medicijnen
- Kan maagpijn veroorzaken
- Consult arts bij bloedstollingsproblemen

**Vormen:**
- **Curcumine Extract:** Beter opneembaar
- **Kurkuma Poeder:** Minder opneembaar
- **Liposomale Curcumine:** Zeer goed opneembaar

### ZWARTE KOMIJNZAAD (NIGELLA SATIVA)

**Voordelen:**
- Ondersteunt immuunsysteem
- Ondersteunt spijsvertering
- Ondersteunt huidgezondheid
- Antioxidant

**Dosering:**
- **Beginner:** 500-1000mg dagelijks
- **Therapeutisch:** 1000-2000mg dagelijks
- **Maximum:** 2000mg dagelijks

**Timing:**
- **Beste:** Ochtend (met voeding)
- **Cold-Pressed:** Beter (niet verhit)
- **Niet Verhit:** Verliest voordelen

**Voorzichtigheid:**
- Kan bloedsuiker verlagen (monitor)
- Kan bloeddruk verlagen (monitor)
- Niet met bepaalde medicijnen
- Consult arts bij diabetes/bloeddruk-medicijnen

**Vormen:**
- **Cold-Pressed Olie:** Beter (niet verhit)
- **Zaad:** Minder opneembaar
- **Extract:** Geconcentreerd

### ASTAXANTHINE

**Voordelen:**
- Zeer krachtige antioxidant
- Vermindert oxidatieve schade
- Ondersteunt oog-gezondheid
- Ondersteunt huidgezondheid

**Dosering:**
- **Beginner:** 4-6mg dagelijks
- **Therapeutisch:** 6-12mg dagelijks
- **Maximum:** 12mg dagelijks

**Timing:**
- **Beste:** Met voeding (betere opname)
- **Met Vet:** Beter opneembaar
- **Dagelijks:** Voor effect

**Voorzichtigheid:**
- Kan bloeddruk licht verlagen
- Niet met bepaalde medicijnen
- Controleer kwaliteit
- Consult arts bij bloeddruk-medicijnen

**Vormen:**
- **Astaxanthine Extract:** Goed opneembaar
- **Natuurlijke Bron:** Beter

---

## Fase-Afhankelijke Supplementen-Protocol

### FASE 1: Acute/Ernstige Toestand (Weken 1-4)

**Doel:** Stabiliseer, verminder symptomen

**Supplementen:**
- Magnesium (avond)
- Probiotica (ochtend)
- Vitamine D (ochtend)
- Zink (ochtend)

**Voorzichtigheid:** Start laag, monitor goed

### FASE 2: Herstel (Weken 5-12)

**Doel:** Ondersteun lichaamsherstel

**Toevoegen:**
- Omega-3 (ochtend)
- Curcumine (ochtend)
- L. Reuteri yogurt (ochtend)
- Zink-carnosine (ochtend)

**Voorzichtigheid:** Voeg één tegelijk toe

### FASE 3: Optimalisatie (Maanden 3+)

**Doel:** Optimaliseer gezondheid

**Toevoegen:**
- Astaxanthine (ochtend)
- Zwarte komijnzaad (ochtend)
- Extra probiotica-variëteit
- Fermentatie groenten (dagelijks)

**Voorzichtigheid:** Onderhoud, niet overmatig

### FASE 4: Onderhoud (Langdurig)

**Doel:** Handhaaf gezondheid

**Minimale Stack:**
- Magnesium (avond)
- Vitamine D (ochtend)
- Omega-3 (ochtend)
- Probiotica (ochtend)

**Voorzichtigheid:** Consistentie is sleutel

---

## Interacties & Voorzorgsmaatregelen

### Gevaarlijke Combinaties
- **Zink + Calcium:** Interactie (scheidt 2 uur)
- **Ijzer + Calcium:** Interactie (scheidt 2 uur)
- **Curcumine + Bloedverdunners:** Verhoogt effect (consult arts)
- **Zwarte Komijn + Bloeddruk-Medicijnen:** Verhoogt effect (consult arts)

### Met Medicijnen
- Check altijd interacties
- Consult arts of apotheker
- Wacht minstens 2 uur tussen supplementen en medicijnen
- Sommige combinaties zijn gevaarlijk

### Detox-Reacties
- **Symptomen:** Hoofdpijn, vermoeidheid, huiduitslag
- **Oorzaak:** Lichaam reinigt zich
- **Duur:** Meestal 3-7 dagen
- **Actie:** Drink meer water, start lager

---

## Bloedwaardes Te Checken

### Essentiële Tests
- Vitamine D
- Ijzer (ferritine, serum ijzer)
- Zink
- Magnesium
- Vitamine B12
- Folaat
- Omega-3 index

### Timing
- **Voor Supplementen:** Baseline bepalen
- **Na 4-6 Weken:** Controleer effect
- **Maandelijks:** Gedurende herstel
- **Jaarlijks:** Onderhoud

---

## Referenties & Onderzoeksbronnen
- Supplement Interactie Databases
- Medische Onderzoeken: Supplementen & Gezondheid
- Dosering Aanbevelingen: NIH, WHO
- Voedingsonderzoeken
